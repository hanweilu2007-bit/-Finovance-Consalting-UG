import { z } from "zod";
import { insertLeadSchema } from "./schema";

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

const leadCreatedResponseSchema = z.object({
  id: z.number().int().positive(),
  createdAt: z.coerce.date().nullable(),
});

// ============================================
// API CONTRACT
// ============================================
export const api = {
  leads: {
    create: {
      method: "POST" as const,
      path: "/api/leads",
      input: insertLeadSchema,
      responses: {
        201: leadCreatedResponseSchema,
        400: errorSchemas.validation,
      },
    },
  },
};

// ============================================
// HELPER FUNCTIONS
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// ============================================
// TYPE HELPERS
// ============================================
export type CreateLeadInput = z.infer<typeof api.leads.create.input>;
export type LeadResponse = z.infer<typeof api.leads.create.responses[201]>;
