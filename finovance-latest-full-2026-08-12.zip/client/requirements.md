## Packages
framer-motion | Smooth animations for page transitions and scroll reveals
react-hook-form | Form state management
zod | Schema validation
@hookform/resolvers | Zod resolver for react-hook-form

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Noto Serif SC'", "serif"],
  body: ["'Noto Sans SC'", "sans-serif"],
}
