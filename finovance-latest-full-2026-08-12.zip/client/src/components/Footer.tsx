import { Link } from "wouter";
import { Mail, MapPin, Phone } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import logoImg from "@assets/Logo_1770322409367.jpg";

export function Footer() {
  const { t } = useI18n();

  return (
    <footer className="bg-primary text-primary-foreground pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="h-12 w-12 bg-white rounded-md overflow-hidden flex items-center justify-center">
                <img src={logoImg} alt="Finovance Consulting" className="h-11 w-11 object-contain" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Finovance Consulting</h3>
                <p className="text-xs text-primary-foreground/70">Finance Innovation Advance</p>
              </div>
            </div>
            <p className="text-primary-foreground/80 leading-relaxed text-sm">
              {t("footer.description")}
            </p>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 text-white">{t("footer.quickLinks")}</h4>
            <ul className="space-y-2">
              <li><Link href="/"><span className="text-primary-foreground/70 hover:text-secondary cursor-pointer transition-colors text-sm" data-testid="link-footer-home">{t("nav.home")}</span></Link></li>
              <li><Link href="/services"><span className="text-primary-foreground/70 hover:text-secondary cursor-pointer transition-colors text-sm" data-testid="link-footer-services">{t("nav.services")}</span></Link></li>
              <li><Link href="/about"><span className="text-primary-foreground/70 hover:text-secondary cursor-pointer transition-colors text-sm" data-testid="link-footer-about">{t("nav.about")}</span></Link></li>
              <li><Link href="/contact"><span className="text-primary-foreground/70 hover:text-secondary cursor-pointer transition-colors text-sm" data-testid="link-footer-contact">{t("nav.contact")}</span></Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 text-white">{t("footer.legalInfo")}</h4>
            <ul className="space-y-2">
              <li><Link href="/impressum"><span className="text-primary-foreground/70 hover:text-secondary cursor-pointer transition-colors text-sm" data-testid="link-footer-impressum">{t("footer.impressum")}</span></Link></li>
              <li><Link href="/datenschutz"><span className="text-primary-foreground/70 hover:text-secondary cursor-pointer transition-colors text-sm" data-testid="link-footer-datenschutz">{t("footer.datenschutz")}</span></Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 text-white">{t("footer.contactInfo")}</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-primary-foreground/80 text-sm">
                <MapPin className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
                <span>{t("footer.location")}</span>
              </li>
              <li className="flex items-center gap-3 text-primary-foreground/80 text-sm">
                <Phone className="w-4 h-4 text-secondary shrink-0" />
                <span>{t("footer.phoneNumber")}</span>
              </li>
              <li className="flex items-center gap-3 text-primary-foreground/80 text-sm">
                <Mail className="w-4 h-4 text-secondary shrink-0" />
                <span>info@finovance.de</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6">
          <p className="text-center text-xs text-primary-foreground/60 mb-4">
            <strong className="text-secondary">{t("footer.riskWarning")}</strong> {t("footer.riskWarningText")}
          </p>
          <p className="text-center text-xs text-primary-foreground/50">
            {t("footer.copyright").replace("{year}", new Date().getFullYear().toString())}
          </p>
        </div>
      </div>
    </footer>
  );
}
