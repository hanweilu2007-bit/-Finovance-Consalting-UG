import { ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { useI18n } from "@/lib/i18n";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
}

export function ServiceCard({ title, description, icon, link }: ServiceCardProps) {
  const { t } = useI18n();

  return (
    <div className="group relative bg-white p-6 sm:p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-border hover:-translate-y-1 overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 bg-secondary/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
      
      <div className="relative z-10">
        <div className="w-12 sm:w-14 h-12 sm:h-14 bg-primary/5 text-primary rounded-lg flex items-center justify-center mb-4 sm:mb-6 group-hover:bg-primary group-hover:text-secondary transition-colors duration-300">
          {icon}
        </div>
        
        <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-primary">{title}</h3>
        <p className="text-muted-foreground mb-4 sm:mb-6 leading-relaxed text-sm sm:text-base">
          {description}
        </p>
        
        <Link href={link}>
          <div className="inline-flex items-center text-secondary font-semibold cursor-pointer group-hover:gap-2 transition-all text-sm sm:text-base">
            {t("common.learnMore")} <ArrowRight className="w-4 h-4 ml-1" />
          </div>
        </Link>
      </div>
    </div>
  );
}
