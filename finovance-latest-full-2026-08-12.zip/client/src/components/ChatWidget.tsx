import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, User, Bot, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useI18n } from "@/lib/i18n";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

interface Conversation {
  id: number;
  title: string;
  sessionId: string;
  status: string;
}

function generateSessionId(): string {
  const storageKey = "finovance-chat-session";
  const stored = localStorage.getItem(storageKey);
  if (stored) return stored;

  const randomPart = typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
  const newId = `session_${randomPart}`;
  localStorage.setItem(storageKey, newId);
  return newId;
}

export function ChatWidget() {
  const { language } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [isHandedOff, setIsHandedOff] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const welcomeMessages: Record<string, string> = {
    zh: "您好！欢迎来到Finovance Consulting。我是您的智能助手，可以为您解答关于私人医疗保险、购房贷款、养老保险和企业保险的常见问题。有什么可以帮您的吗？",
    en: "Hello! Welcome to Finovance Consulting. I'm your AI assistant and can help answer common questions about private health insurance, mortgages, pension planning, and corporate insurance. How can I help you today?",
    de: "Hallo! Willkommen bei Finovance Consulting. Ich bin Ihr KI-Assistent und kann Ihnen bei häufigen Fragen zu privater Krankenversicherung, Immobilienfinanzierung, Altersvorsorge und Gewerbeversicherung helfen. Wie kann ich Ihnen heute helfen?",
  };

  const placeholders: Record<string, string> = {
    zh: "输入您的问题...",
    en: "Type your question...",
    de: "Geben Sie Ihre Frage ein...",
  };

  const headerTitles: Record<string, string> = {
    zh: "Finovance 智能助手",
    en: "Finovance AI Assistant",
    de: "Finovance KI-Assistent",
  };

  const statusTexts: Record<string, { online: string; handedOff: string }> = {
    zh: { online: "在线服务中", handedOff: "已转接人工服务" },
    en: { online: "Online", handedOff: "Transferred to human agent" },
    de: { online: "Online", handedOff: "An Berater weitergeleitet" },
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (isOpen && !conversation) {
      initSession();
    }
  }, [isOpen]);

  const initSession = async () => {
    try {
      const sessionId = generateSessionId();
      const response = await fetch("/api/chatbot/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId }),
      });
      if (!response.ok) {
        throw new Error(`Chat session request failed with status ${response.status}`);
      }
      const data = await response.json();
      setConversation(data.conversation);
      
      if (data.messages && data.messages.length > 0) {
        setMessages(data.messages);
        if (data.conversation.status === "pending_human") {
          setIsHandedOff(true);
        }
      } else {
        // Add welcome message
        setMessages([{
          id: 0,
          role: "assistant",
          content: welcomeMessages[language] || welcomeMessages.zh,
          createdAt: new Date().toISOString(),
        }]);
      }
    } catch (error) {
      console.error("Failed to init chat session:", error);
      const errorMessages: Record<string, string> = {
        zh: "连接失败，请稍后重试",
        en: "Connection failed, please try again later",
        de: "Verbindung fehlgeschlagen, bitte versuchen Sie es später erneut",
      };
      setMessages([{
        id: 0,
        role: "assistant",
        content: errorMessages[language] || errorMessages.zh,
        createdAt: new Date().toISOString(),
      }]);
    }
  };

  const sendMessage = async () => {
    if (!inputValue.trim() || isLoading || !conversation) return;

    const userMessage: Message = {
      id: Date.now(),
      role: "user",
      content: inputValue.trim(),
      createdAt: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/chatbot/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: conversation.id,
          sessionId: conversation.sessionId,
          content: userMessage.content,
        }),
      });

      if (!response.ok) {
        const errorBody = await response.json().catch(() => null);
        throw new Error(errorBody?.error || `Failed to send message (${response.status})`);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error("No response body");

      const decoder = new TextDecoder();
      let assistantContent = "";
      const assistantMessageId = Date.now() + 1;

      // Add empty assistant message
      setMessages(prev => [...prev, {
        id: assistantMessageId,
        role: "assistant",
        content: "",
        createdAt: new Date().toISOString(),
      }]);

      let streamBuffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        streamBuffer += decoder.decode(value, { stream: true });
        const events = streamBuffer.split("\n\n");
        streamBuffer = events.pop() || "";

        for (const event of events) {
          const dataLine = event.split("\n").find((line) => line.startsWith("data: "));
          if (!dataLine) continue;

          try {
            const data = JSON.parse(dataLine.slice(6));
            if (data.content) {
              assistantContent += data.content;
              setMessages((previous) => previous.map((message) =>
                message.id === assistantMessageId
                  ? { ...message, content: assistantContent }
                  : message,
              ));
            }
            if (data.handoff) {
              setIsHandedOff(true);
            }
          } catch {
            // Ignore malformed stream events and continue reading.
          }
        }
      }
    } catch (error) {
      console.error("Failed to send message:", error);
      const errorMessages: Record<string, string> = {
        zh: "发送失败，请重试",
        en: "Failed to send, please try again",
        de: "Senden fehlgeschlagen, bitte erneut versuchen",
      };
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        role: "assistant",
        content: errorMessages[language] || errorMessages.zh,
        createdAt: new Date().toISOString(),
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-primary text-white shadow-lg hover:bg-primary/90 transition-all flex items-center justify-center"
        data-testid="button-chat-toggle"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-[360px] max-w-[calc(100vw-48px)] h-[500px] max-h-[calc(100vh-120px)] bg-white rounded-2xl shadow-2xl border border-border flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-primary text-white p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold">{headerTitles[language] || headerTitles.zh}</h3>
              <p className="text-xs text-white/70">
                {isHandedOff 
                  ? (statusTexts[language]?.handedOff || statusTexts.zh.handedOff)
                  : (statusTexts[language]?.online || statusTexts.zh.online)
                }
              </p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-2 ${message.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  message.role === "user" ? "bg-primary text-white" : "bg-secondary text-primary"
                }`}>
                  {message.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
                <div className={`max-w-[75%] p-3 rounded-2xl text-sm leading-relaxed ${
                  message.role === "user" 
                    ? "bg-primary text-white rounded-tr-none" 
                    : "bg-white text-foreground rounded-tl-none shadow-sm border border-border"
                }`}>
                  {message.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-2">
                <div className="w-8 h-8 rounded-full bg-secondary text-primary flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="bg-white p-3 rounded-2xl rounded-tl-none shadow-sm border border-border">
                  <Loader2 className="w-4 h-4 animate-spin text-primary" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t border-border bg-white">
            <div className="flex gap-2">
              <Input
                value={inputValue}
                maxLength={2000}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={placeholders[language] || placeholders.zh}
                disabled={isLoading}
                className="flex-1"
                data-testid="input-chat-message"
              />
              <Button 
                onClick={sendMessage} 
                disabled={!inputValue.trim() || isLoading}
                size="icon"
                data-testid="button-chat-send"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
