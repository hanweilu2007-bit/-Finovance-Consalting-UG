import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertLeadSchema } from "@shared/schema";
import { useCreateLead } from "@/hooks/use-leads";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { Link } from "wouter";
import { useI18n } from "@/lib/i18n";
import type { z } from "zod";

type FormData = z.infer<typeof insertLeadSchema>;

export function ContactForm() {
  const { mutate, isPending } = useCreateLead();
  const { t, language } = useI18n();
  
  const form = useForm<FormData>({
    resolver: zodResolver(insertLeadSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
      consentToPrivacy: false,
      acceptedDisclaimer: false,
    },
  });

  const onSubmit = (data: FormData) => {
    mutate(data, {
      onSuccess: () => {
        form.reset();
      }
    });
  };

  const serviceOptions = [
    { value: "private_health", label: t("contact.serviceOptions.private_health") },
    { value: "mortgage", label: t("contact.serviceOptions.mortgage") },
    { value: "pension", label: t("contact.serviceOptions.pension") },
    { value: "corporate", label: t("contact.serviceOptions.corporate") },
    { value: "other", label: t("contact.serviceOptions.other") },
  ];

  return (
    <div className="bg-white p-4 sm:p-6 md:p-8 rounded-2xl shadow-xl border border-border">
      <h3 className="text-xl sm:text-2xl font-bold text-primary mb-2">{t("contact.formTitle")}</h3>
      <p className="text-muted-foreground text-sm mb-6">{t("contact.formSubtitle")}</p>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("contact.name")} {t("contact.required")}</FormLabel>
                  <FormControl>
                    <Input placeholder={t("contact.namePlaceholder")} {...field} className="h-11" data-testid="input-name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("contact.phone")} {t("contact.required")}</FormLabel>
                  <FormControl>
                    <Input placeholder={t("contact.phonePlaceholder")} {...field} className="h-11" data-testid="input-phone" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("contact.email")} {t("contact.required")}</FormLabel>
                <FormControl>
                  <Input placeholder={t("contact.emailPlaceholder")} {...field} className="h-11" data-testid="input-email" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="serviceInterest"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("contact.service")} {t("contact.required")}</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger className="h-11" data-testid="select-service">
                      <SelectValue placeholder={t("contact.servicePlaceholder")} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {serviceOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="message"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("contact.message")}</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder={t("contact.messagePlaceholder")} 
                    className="min-h-[100px] resize-none" 
                    {...field} 
                    value={field.value ?? ""}
                    data-testid="textarea-message"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-4 pt-2">
            <FormField
              control={form.control}
              name="consentToPrivacy"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-privacy"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-sm font-normal cursor-pointer">
                      {t("contact.privacyConsent")}{" "}
                      <Link href="/datenschutz">
                        <span className="text-primary underline hover:text-secondary">{t("contact.privacyPolicy")}</span>
                      </Link>
                      {" "}{t("contact.required")}
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="acceptedDisclaimer"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-disclaimer"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-sm font-normal cursor-pointer">
                      {t("contact.disclaimerConsent")}{" "}
                      <Link href="/impressum">
                        <span className="text-primary underline hover:text-secondary">{t("contact.disclaimer")}</span>
                      </Link>
                      {" "}{t("contact.riskWarning")} {t("contact.required")}
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />
          </div>

          <Button 
            type="submit" 
            className="w-full h-12 text-base sm:text-lg font-semibold bg-secondary text-primary hover:bg-secondary/90"
            disabled={isPending}
            data-testid="button-submit"
          >
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> {t("contact.submitting")}
              </>
            ) : (
              t("contact.submit")
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
}
