import { Link, useLocation } from "wouter";
import { Menu, X, Phone } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { useI18n } from "@/lib/i18n";
import logoImg from "@assets/Logo_1770322409367.jpg";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { t } = useI18n();

  const links = [
    { href: "/", label: t("nav.home") },
    { href: "/services", label: t("nav.services") },
    { href: "/about", label: t("nav.about") },
    { href: "/contact", label: t("nav.contact") },
  ];

  const isActive = (path: string) => location === path;

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <div className="flex items-center gap-3 cursor-pointer" data-testid="link-home-logo">
            <img src={logoImg} alt="Finovance Consulting" className="h-10 w-10 object-contain mix-blend-multiply" />
            <div className="hidden sm:block">
              <span className="text-lg font-bold text-primary">Finovance Consulting</span>
              <p className="text-xs text-muted-foreground -mt-0.5">Finance Innovation Advance</p>
            </div>
          </div>
        </Link>

        <div className="hidden md:flex items-center gap-6">
          {links.map((link) => (
            <Link key={link.href} href={link.href}>
              <span 
                className={`text-sm font-medium transition-colors hover:text-secondary cursor-pointer ${
                  isActive(link.href) ? "text-primary font-bold" : "text-muted-foreground"
                }`}
                data-testid={`link-nav-${link.href.replace("/", "") || "home"}`}
              >
                {link.label}
              </span>
            </Link>
          ))}
          <LanguageSwitcher />
          <Link href="/contact">
            <Button size="sm" className="bg-secondary text-primary hover:bg-secondary/90 font-semibold" data-testid="button-nav-consult">
              <Phone className="w-4 h-4 mr-2" />
              {t("nav.consult")}
            </Button>
          </Link>
        </div>

        <div className="flex items-center gap-2 md:hidden">
          <LanguageSwitcher />
          <button
            className="p-2 text-primary"
            onClick={() => setIsOpen(!isOpen)}
            data-testid="button-mobile-menu"
          >
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden absolute top-16 left-0 w-full bg-background border-b border-border p-4 shadow-lg animate-in slide-in-from-top-5">
          <div className="flex flex-col gap-4">
            {links.map((link) => (
              <Link key={link.href} href={link.href}>
                <span 
                  className={`block py-2 text-base font-medium ${
                    isActive(link.href) ? "text-primary" : "text-muted-foreground"
                  }`}
                  onClick={() => setIsOpen(false)}
                  data-testid={`link-mobile-${link.href.replace("/", "") || "home"}`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
            <Link href="/contact">
              <Button className="w-full bg-secondary text-primary font-bold mt-2" onClick={() => setIsOpen(false)} data-testid="button-mobile-consult">
                {t("nav.consult")}
              </Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
