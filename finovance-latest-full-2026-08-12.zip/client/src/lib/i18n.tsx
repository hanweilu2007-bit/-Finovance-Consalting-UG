import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

export type Language = "zh" | "en" | "de";

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  tArray: <T = unknown>(key: string) => T[];
  tObject: <T = Record<string, unknown>>(key: string) => T;
}

const I18nContext = createContext<I18nContextType | null>(null);

const STORAGE_KEY = "finovance-language";

function getInitialLanguage(): Language {
  if (typeof window !== "undefined") {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === "zh" || saved === "en" || saved === "de") {
      return saved;
    }
  }
  return "zh";
}

const initialLang = getInitialLanguage();
if (typeof document !== "undefined") {
  document.documentElement.lang = initialLang;
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(initialLang);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(STORAGE_KEY, lang);
    document.documentElement.lang = lang;
  };

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const getValue = (key: string): unknown => {
    const keys = key.split(".");
    let value: unknown = translations[language];
    
    for (const k of keys) {
      if (value && typeof value === "object" && k in value) {
        value = (value as Record<string, unknown>)[k];
      } else {
        return undefined;
      }
    }
    
    return value;
  };

  const t = (key: string): string => {
    const value = getValue(key);
    return typeof value === "string" ? value : key;
  };

  const tArray = <T = unknown,>(key: string): T[] => {
    const value = getValue(key);
    return Array.isArray(value) ? value : [];
  };

  const tObject = <T = Record<string, unknown>,>(key: string): T => {
    const value = getValue(key);
    return (value && typeof value === "object" && !Array.isArray(value) ? value : {}) as T;
  };

  return (
    <I18nContext.Provider value={{ language, setLanguage, t, tArray, tObject }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error("useI18n must be used within I18nProvider");
  }
  return context;
}

export const translations: Record<Language, Record<string, unknown>> = {
  zh: {
    nav: {
      home: "首页",
      services: "服务项目",
      about: "关于我们",
      contact: "联系我们",
      consult: "预约咨询",
    },
    home: {
      heroTitle: "深度理解德国金融体系",
      heroHighlight: "为您的财富稳健增值",
      heroSubtitle: "Finovance Consulting — 您的中德金融桥梁",
      heroDescription: "语言不再是障碍，用您的母语为您解读复杂的德国保险、贷款与理财体系",
      consultBtn: "预约私人咨询",
      learnMore: "了解服务",
      tagline: "专业、诚信、贴心",
      taglineDesc: "作为专注服务德国华人高净值客户的金融顾问，我们深知语言和文化差异带来的挑战。德国的保险、房贷和理财体系与中国截然不同，非母语者难以完全理解其中的复杂条款。我们用您熟悉的语言，为您提供专业的财务规划服务。",
      coreServices: "核心服务",
      whyUs: "为什么选择我们？",
      whyUsItems: [
        "中文母语服务，无沟通障碍",
        "深谙德国金融体系，专业解读复杂条款",
        "合作多家顶级保险公司与银行，选择多样",
        "一对一量身定制方案，拒绝千篇一律",
        "全程贴心服务，理赔协助无忧"
      ],
      serviceCards: [
        { title: "私人医疗保险", description: "为您量身定制最适合的私人医保方案，享受德国顶级医疗资源。" },
        { title: "购房贷款", description: "协助您获取最优利率的房贷方案，轻松实现在德置业梦想。" },
        { title: "养老保险", description: "科学规划退休生活，确保您在德国拥有体面的养老保障。" },
        { title: "企业保险", description: "为您的企业提供全方位的风险保障方案，助力事业稳健发展。" }
      ],
      ctaTitle: "准备好规划您的财务未来了吗？",
      ctaDesc: "立即预约免费咨询，让我们用您的母语为您开启财富增值之旅。",
      ctaBtn: "立即预约",
    },
    services: {
      title: "服务项目",
      subtitle: "我们专注于为德国华人高净值客户提供专业的金融咨询服务，用您的母语解读复杂的德国金融体系。",
      privateHealth: {
        tag: "私人医疗保险",
        title: "Private Krankenversicherung (PKV)",
        description: "德国的医疗保险体系分为公立 (GKV) 和私立 (PKV) 两大类。私人医疗保险为您提供更优质的医疗服务、更短的等待时间和更全面的保障。我们帮助您深入了解其中的差异，选择最适合您的方案。",
        features: [
          { title: "全面保障", desc: "涵盖门诊、住院、牙科及专科治疗。" },
          { title: "顶级医疗资源", desc: "优先预约专家门诊，享受主任医生诊治。" },
          { title: "灵活定制", desc: "根据您的健康状况和预算量身定制。" }
        ],
        cta: "咨询私人医保"
      },
      mortgage: {
        tag: "购房贷款",
        title: "Immobilienfinanzierung",
        description: "在德国购房是重要的人生决定。德国的房贷体系与中国有很大不同，包括固定利率期限、Tilgungsrate（还款比例）等概念。我们为您争取最优利率，确保您充分理解每一个条款。",
        features: [
          { title: "首次购房贷款", desc: "为您的德国置业梦想提供专业支持。" },
          { title: "Anschlussfinanzierung (续贷)", desc: "固定利率期满后的最优续贷方案。" },
          { title: "多银行比价", desc: "对接数百家银行，为您争取最低利率。" }
        ],
        cta: "评估贷款额度"
      },
      pension: {
        tag: "养老保险",
        title: "Altersvorsorge",
        description: "德国的养老体系采用三支柱模式：法定养老保险、企业补充养老和私人养老保险。仅靠法定养老金难以保障高品质的退休生活，及早规划私人养老保险至关重要。",
        features: [
          { title: "Riester-Rente", desc: "享受国家补贴和税收优惠的养老方案。" },
          { title: "Rürup-Rente (Basisrente)", desc: "自雇人士和高收入者的最佳选择。" },
          { title: "私人养老储蓄", desc: "灵活的投资组合，稳健增值。" }
        ],
        cta: "规划养老方案"
      },
      corporate: {
        tag: "企业保险",
        title: "Gewerbeversicherung",
        description: "无论您是自由职业者还是企业主，合适的商业保险是事业成功的基石。我们帮助您识别经营风险，提供全面的企业保障方案。",
        features: [
          { title: "Betriebshaftpflicht (企业责任险)", desc: "保障因企业活动造成的第三方损失。" },
          { title: "Berufshaftpflicht (职业责任险)", desc: "专业人士必备，保障职业过失风险。" },
          { title: "D&O 董事责任险", desc: "保护管理层个人免受经营决策风险。" }
        ],
        cta: "咨询企业保险"
      }
    },
    about: {
      title: "关于我们",
      subtitle: "Finovance Consulting — 您的中德金融桥梁",
      sectionTitle: "用您的母语，为您解读德国金融",
      p1: "德国的保险、贷款和理财体系与中国截然不同。复杂的条款、专业的术语，即使是德语流利的华人朋友，也可能难以完全理解其中的细微差别和潜在风险。",
      p2: "Finovance Consulting 专注于服务在德华人高净值客户。我们不仅精通德国金融体系的每一个细节，更能用您熟悉的语言和思维方式，为您清晰解读每一个条款，确保您做出最明智的财务决策。",
      p3: "我们的使命是成为您在德国的金融伙伴，让语言不再是障碍，让复杂的金融决策变得简单透明。",
      consultantTitle: "您的专属顾问",
      consultantName: "[顾问姓名]",
      consultantRole: "高级金融顾问",
      consultantBio1: "[在此处添加顾问的个人简介...]",
      consultantBio2: "[教育背景、从业经历、专业资质等...]",
      expertise: "专业领域：",
      expertiseAreas: ["私人医疗保险", "购房贷款", "养老保险", "企业保险"],
      valuesTitle: "我们的核心价值",
      values: {
        professional: { title: "专业", desc: "深耕德国金融市场，持有相关专业资质，为您提供最专业的建议。" },
        crossCultural: { title: "跨文化", desc: "理解中德两国的文化差异，用您熟悉的方式沟通复杂的金融概念。" },
        integrity: { title: "诚信", desc: "以客户利益为先，提供透明、诚实的建议，建立长期信任关系。" },
        caring: { title: "贴心", desc: "一对一专属服务，全程陪伴，从咨询到理赔，始终在您身边。" }
      },
      ctaTitle: "让我们开始对话",
      ctaDesc: "无论您是刚来德国的新移民，还是已经在这里生活多年的老朋友，我们都期待与您交流，为您的财务规划提供专业支持。",
      ctaBtn: "预约咨询"
    },
    contact: {
      title: "联系我们",
      subtitle: "期待与您建立联系，为您的财务规划提供专业支持。",
      formTitle: "预约私人咨询",
      formSubtitle: "请填写以下信息，我们将尽快与您联系。",
      name: "姓名",
      namePlaceholder: "您的称呼",
      phone: "电话",
      phonePlaceholder: "+49 ...",
      email: "邮箱",
      emailPlaceholder: "example@email.com",
      service: "感兴趣的服务",
      servicePlaceholder: "请选择服务类型",
      serviceOptions: {
        private_health: "私人医疗保险 (Private Health Insurance)",
        mortgage: "购房贷款 (Mortgage)",
        pension: "养老保险 (Pension)",
        corporate: "企业保险 (Corporate Insurance)",
        other: "其他咨询 (Other)"
      },
      message: "留言内容",
      messagePlaceholder: "请简述您的需求或问题...",
      privacyConsent: "我已阅读并同意",
      privacyPolicy: "隐私政策 (Datenschutzerklärung)",
      disclaimerConsent: "我已阅读并确认",
      disclaimer: "免责声明 (Haftungsausschluss)",
      riskWarning: "与风险提示",
      submit: "提交咨询",
      submitting: "提交中...",
      required: "*",
      callTitle: "致电咨询",
      callHours: "周一至周五 9:00 - 17:00",
      emailTitle: "发送邮件",
      emailDesc: "我们会尽快回复您的咨询",
      locationTitle: "办公地址"
    },
    footer: {
      description: "专注于服务德国华人高净值客户，用您的母语为您解读复杂的德国金融体系。",
      quickLinks: "快速链接",
      legalInfo: "法律信息",
      impressum: "Impressum (法律声明)",
      datenschutz: "Datenschutz (隐私政策)",
      contactInfo: "联系方式",
      location: "德国",
      phoneNumber: "待更新",
      riskWarning: "风险提示：",
      riskWarningText: "理财有风险，投资需谨慎。本网站提供的信息仅供参考，不构成法律、税务或投资建议。请在做出任何财务决策之前咨询专业顾问。",
      copyright: "© {year} Finovance Consulting. All rights reserved."
    },
    common: {
      learnMore: "了解详情"
    }
  },
  en: {
    nav: {
      home: "Home",
      services: "Services",
      about: "About Us",
      contact: "Contact",
      consult: "Book Consultation",
    },
    home: {
      heroTitle: "Deep Understanding of German Finance",
      heroHighlight: "Grow Your Wealth Steadily",
      heroSubtitle: "Finovance Consulting — Your Bridge to German Finance",
      heroDescription: "Language is no longer a barrier. We explain complex German insurance, mortgages, and wealth management in your native language.",
      consultBtn: "Book Private Consultation",
      learnMore: "Learn More",
      tagline: "Professional, Trustworthy, Caring",
      taglineDesc: "As financial advisors dedicated to serving high-net-worth Chinese clients in Germany, we understand the challenges of language and cultural differences. The German insurance, mortgage, and wealth management systems are vastly different from China's, making it difficult for non-native speakers to fully understand complex terms. We provide professional financial planning services in your familiar language.",
      coreServices: "Core Services",
      whyUs: "Why Choose Us?",
      whyUsItems: [
        "Native Chinese service, no communication barriers",
        "Deep expertise in German financial systems",
        "Partnerships with top insurance companies and banks",
        "Personalized solutions, tailored to your needs",
        "Full-service support, including claims assistance"
      ],
      serviceCards: [
        { title: "Private Health Insurance", description: "Customized private health insurance plans with access to Germany's top medical resources." },
        { title: "Mortgage", description: "Get the best mortgage rates and make your German property dreams a reality." },
        { title: "Pension Planning", description: "Plan for a dignified retirement in Germany with comprehensive pension strategies." },
        { title: "Corporate Insurance", description: "Comprehensive risk protection for your business to ensure steady growth." }
      ],
      ctaTitle: "Ready to Plan Your Financial Future?",
      ctaDesc: "Book a free consultation today and let us guide your wealth journey in your native language.",
      ctaBtn: "Book Now",
    },
    services: {
      title: "Our Services",
      subtitle: "We specialize in providing professional financial consulting services for high-net-worth Chinese clients in Germany, explaining complex German financial systems in your native language.",
      privateHealth: {
        tag: "Private Health Insurance",
        title: "Private Krankenversicherung (PKV)",
        description: "Germany's healthcare system is divided into public (GKV) and private (PKV) insurance. Private health insurance offers better medical services, shorter waiting times, and more comprehensive coverage. We help you understand the differences and choose the best plan for you.",
        features: [
          { title: "Comprehensive Coverage", desc: "Covers outpatient, inpatient, dental, and specialist treatments." },
          { title: "Premium Healthcare", desc: "Priority appointments with specialists and chief physicians." },
          { title: "Flexible Plans", desc: "Customized based on your health status and budget." }
        ],
        cta: "Consult on Private Health Insurance"
      },
      mortgage: {
        tag: "Mortgage",
        title: "Immobilienfinanzierung",
        description: "Buying property in Germany is a major life decision. The German mortgage system differs significantly from China's, including concepts like fixed interest periods and Tilgungsrate (repayment rate). We help you secure the best rates and fully understand every term.",
        features: [
          { title: "First-time Buyer Loans", desc: "Professional support for your German property dreams." },
          { title: "Anschlussfinanzierung (Refinancing)", desc: "Optimal refinancing solutions when your fixed rate expires." },
          { title: "Multi-Bank Comparison", desc: "Access to hundreds of banks for the lowest rates." }
        ],
        cta: "Assess Your Loan Amount"
      },
      pension: {
        tag: "Pension Planning",
        title: "Altersvorsorge",
        description: "Germany's pension system uses a three-pillar model: statutory pension, company pension, and private pension. Relying solely on statutory pension is not enough for a high-quality retirement. Early planning for private pension is crucial.",
        features: [
          { title: "Riester-Rente", desc: "Enjoy government subsidies and tax benefits." },
          { title: "Rürup-Rente (Basisrente)", desc: "Best choice for self-employed and high-income earners." },
          { title: "Private Pension Savings", desc: "Flexible investment portfolios with steady growth." }
        ],
        cta: "Plan Your Pension"
      },
      corporate: {
        tag: "Corporate Insurance",
        title: "Gewerbeversicherung",
        description: "Whether you're a freelancer or business owner, proper commercial insurance is the cornerstone of business success. We help you identify operational risks and provide comprehensive business protection solutions.",
        features: [
          { title: "Betriebshaftpflicht (Business Liability)", desc: "Protection against third-party damages from business activities." },
          { title: "Berufshaftpflicht (Professional Liability)", desc: "Essential for professionals, covers professional negligence risks." },
          { title: "D&O Insurance", desc: "Protects management from personal liability for business decisions." }
        ],
        cta: "Consult on Corporate Insurance"
      }
    },
    about: {
      title: "About Us",
      subtitle: "Finovance Consulting — Your Bridge to German Finance",
      sectionTitle: "Understanding German Finance in Your Language",
      p1: "Germany's insurance, mortgage, and wealth management systems are vastly different from China's. Complex terms and professional jargon can be difficult to fully understand, even for those fluent in German.",
      p2: "Finovance Consulting specializes in serving high-net-worth Chinese clients in Germany. We not only master every detail of the German financial system but also explain each term clearly in your familiar language and mindset, ensuring you make the wisest financial decisions.",
      p3: "Our mission is to be your financial partner in Germany, where language is no longer a barrier and complex financial decisions become simple and transparent.",
      consultantTitle: "Your Dedicated Consultant",
      consultantName: "[Consultant Name]",
      consultantRole: "Senior Financial Consultant",
      consultantBio1: "[Add consultant bio here...]",
      consultantBio2: "[Education, experience, qualifications...]",
      expertise: "Areas of Expertise:",
      expertiseAreas: ["Private Health Insurance", "Mortgage", "Pension Planning", "Corporate Insurance"],
      valuesTitle: "Our Core Values",
      values: {
        professional: { title: "Professional", desc: "Deep expertise in German financial markets with relevant qualifications." },
        crossCultural: { title: "Cross-Cultural", desc: "Understanding cultural differences between China and Germany." },
        integrity: { title: "Integrity", desc: "Putting client interests first with transparent, honest advice." },
        caring: { title: "Caring", desc: "Personalized one-on-one service, from consultation to claims." }
      },
      ctaTitle: "Let's Start a Conversation",
      ctaDesc: "Whether you're a newcomer to Germany or have lived here for years, we look forward to connecting with you and providing professional support for your financial planning.",
      ctaBtn: "Book Consultation"
    },
    contact: {
      title: "Contact Us",
      subtitle: "We look forward to connecting with you and providing professional support for your financial planning.",
      formTitle: "Book a Private Consultation",
      formSubtitle: "Please fill in the information below and we will contact you shortly.",
      name: "Name",
      namePlaceholder: "Your name",
      phone: "Phone",
      phonePlaceholder: "+49 ...",
      email: "Email",
      emailPlaceholder: "example@email.com",
      service: "Service of Interest",
      servicePlaceholder: "Select service type",
      serviceOptions: {
        private_health: "Private Health Insurance",
        mortgage: "Mortgage",
        pension: "Pension Planning",
        corporate: "Corporate Insurance",
        other: "Other Inquiry"
      },
      message: "Message",
      messagePlaceholder: "Please describe your needs or questions...",
      privacyConsent: "I have read and agree to the",
      privacyPolicy: "Privacy Policy (Datenschutzerklärung)",
      disclaimerConsent: "I have read and confirm the",
      disclaimer: "Disclaimer (Haftungsausschluss)",
      riskWarning: "and risk notice",
      submit: "Submit Inquiry",
      submitting: "Submitting...",
      required: "*",
      callTitle: "Call Us",
      callHours: "Monday - Friday 9:00 - 17:00",
      emailTitle: "Send Email",
      emailDesc: "We'll respond to your inquiry promptly",
      locationTitle: "Office Location"
    },
    footer: {
      description: "Dedicated to serving high-net-worth Chinese clients in Germany, explaining complex German financial systems in your native language.",
      quickLinks: "Quick Links",
      legalInfo: "Legal Information",
      impressum: "Impressum (Legal Notice)",
      datenschutz: "Datenschutz (Privacy Policy)",
      contactInfo: "Contact Information",
      location: "Germany",
      phoneNumber: "To be updated",
      riskWarning: "Risk Warning:",
      riskWarningText: "Investment carries risks. The information on this website is for reference only and does not constitute legal, tax, or investment advice. Please consult a professional advisor before making any financial decisions.",
      copyright: "© {year} Finovance Consulting. All rights reserved."
    },
    common: {
      learnMore: "Learn More"
    }
  },
  de: {
    nav: {
      home: "Startseite",
      services: "Leistungen",
      about: "Über uns",
      contact: "Kontakt",
      consult: "Beratung buchen",
    },
    home: {
      heroTitle: "Tiefes Verständnis des deutschen Finanzsystems",
      heroHighlight: "Lassen Sie Ihr Vermögen stetig wachsen",
      heroSubtitle: "Finovance Consulting — Ihre Brücke zur deutschen Finanzwelt",
      heroDescription: "Sprache ist keine Barriere mehr. Wir erklären komplexe deutsche Versicherungen, Hypotheken und Vermögensverwaltung in Ihrer Muttersprache.",
      consultBtn: "Beratung vereinbaren",
      learnMore: "Mehr erfahren",
      tagline: "Professionell, Vertrauenswürdig, Fürsorglich",
      taglineDesc: "Als Finanzberater, die sich auf vermögende chinesische Kunden in Deutschland spezialisiert haben, verstehen wir die Herausforderungen von Sprach- und Kulturunterschieden. Das deutsche Versicherungs-, Hypotheken- und Vermögensverwaltungssystem unterscheidet sich stark von dem in China. Wir bieten professionelle Finanzplanung in Ihrer vertrauten Sprache.",
      coreServices: "Unsere Kernleistungen",
      whyUs: "Warum uns wählen?",
      whyUsItems: [
        "Chinesischsprachiger Service ohne Kommunikationsbarrieren",
        "Tiefe Expertise im deutschen Finanzsystem",
        "Partnerschaften mit führenden Versicherungen und Banken",
        "Maßgeschneiderte Lösungen für Ihre Bedürfnisse",
        "Rundum-Service inklusive Schadensabwicklung"
      ],
      serviceCards: [
        { title: "Private Krankenversicherung", description: "Maßgeschneiderte PKV-Tarife mit Zugang zu Deutschlands besten medizinischen Ressourcen." },
        { title: "Immobilienfinanzierung", description: "Sichern Sie sich die besten Hypothekenzinsen für Ihren Traum vom Eigenheim." },
        { title: "Altersvorsorge", description: "Planen Sie einen würdevollen Ruhestand mit umfassenden Vorsorgestrategien." },
        { title: "Gewerbeversicherung", description: "Umfassender Risikoschutz für Ihr Unternehmen und stetiges Wachstum." }
      ],
      ctaTitle: "Bereit, Ihre finanzielle Zukunft zu planen?",
      ctaDesc: "Vereinbaren Sie noch heute eine kostenlose Beratung und lassen Sie uns Ihre Vermögensreise in Ihrer Muttersprache begleiten.",
      ctaBtn: "Jetzt buchen",
    },
    services: {
      title: "Unsere Leistungen",
      subtitle: "Wir sind spezialisiert auf professionelle Finanzberatung für vermögende chinesische Kunden in Deutschland und erklären komplexe deutsche Finanzsysteme in Ihrer Muttersprache.",
      privateHealth: {
        tag: "Private Krankenversicherung",
        title: "Private Krankenversicherung (PKV)",
        description: "Das deutsche Gesundheitssystem besteht aus gesetzlicher (GKV) und privater (PKV) Versicherung. Die private Krankenversicherung bietet bessere medizinische Leistungen, kürzere Wartezeiten und umfassendere Absicherung. Wir helfen Ihnen, die Unterschiede zu verstehen und den besten Plan für Sie zu wählen.",
        features: [
          { title: "Umfassende Absicherung", desc: "Abdeckung von ambulanten, stationären, Zahn- und Facharztbehandlungen." },
          { title: "Premium-Gesundheitsversorgung", desc: "Bevorzugte Termine bei Spezialisten und Chefärzten." },
          { title: "Flexible Tarife", desc: "Individuell angepasst an Ihren Gesundheitszustand und Ihr Budget." }
        ],
        cta: "PKV-Beratung anfragen"
      },
      mortgage: {
        tag: "Immobilienfinanzierung",
        title: "Immobilienfinanzierung",
        description: "Der Immobilienkauf in Deutschland ist eine wichtige Lebensentscheidung. Das deutsche Hypothekensystem unterscheidet sich erheblich vom chinesischen, einschließlich Konzepten wie Zinsbindung und Tilgungsrate. Wir helfen Ihnen, die besten Konditionen zu sichern und jeden Begriff vollständig zu verstehen.",
        features: [
          { title: "Erstkäufer-Darlehen", desc: "Professionelle Unterstützung für Ihren Traum vom Eigenheim in Deutschland." },
          { title: "Anschlussfinanzierung", desc: "Optimale Lösungen nach Ablauf Ihrer Zinsbindung." },
          { title: "Multibank-Vergleich", desc: "Zugang zu Hunderten von Banken für die niedrigsten Zinsen." }
        ],
        cta: "Finanzierung berechnen"
      },
      pension: {
        tag: "Altersvorsorge",
        title: "Altersvorsorge",
        description: "Das deutsche Rentensystem basiert auf einem Drei-Säulen-Modell: gesetzliche Rente, betriebliche Altersvorsorge und private Vorsorge. Die gesetzliche Rente allein reicht nicht für einen hochwertigen Ruhestand. Frühzeitige Planung der privaten Altersvorsorge ist entscheidend.",
        features: [
          { title: "Riester-Rente", desc: "Profitieren Sie von staatlichen Zulagen und Steuervorteilen." },
          { title: "Rürup-Rente (Basisrente)", desc: "Beste Wahl für Selbstständige und Gutverdiener." },
          { title: "Private Altersvorsorge", desc: "Flexible Anlageportfolios mit stetigem Wachstum." }
        ],
        cta: "Altersvorsorge planen"
      },
      corporate: {
        tag: "Gewerbeversicherung",
        title: "Gewerbeversicherung",
        description: "Ob Freiberufler oder Unternehmer – die richtige Gewerbeversicherung ist das Fundament Ihres Geschäftserfolgs. Wir helfen Ihnen, Betriebsrisiken zu identifizieren und bieten umfassende Absicherungslösungen.",
        features: [
          { title: "Betriebshaftpflicht", desc: "Schutz gegen Schäden Dritter durch Geschäftstätigkeiten." },
          { title: "Berufshaftpflicht", desc: "Unverzichtbar für Freiberufler, deckt berufliche Fahrlässigkeit ab." },
          { title: "D&O-Versicherung", desc: "Schützt Führungskräfte vor persönlicher Haftung für Geschäftsentscheidungen." }
        ],
        cta: "Gewerbeversicherung anfragen"
      }
    },
    about: {
      title: "Über uns",
      subtitle: "Finovance Consulting — Ihre Brücke zur deutschen Finanzwelt",
      sectionTitle: "Deutsche Finanzen in Ihrer Sprache verstehen",
      p1: "Das deutsche Versicherungs-, Hypotheken- und Vermögensverwaltungssystem unterscheidet sich stark von dem in China. Komplexe Begriffe und Fachjargon können selbst für Deutschsprachige schwer vollständig zu verstehen sein.",
      p2: "Finovance Consulting ist auf die Betreuung vermögender chinesischer Kunden in Deutschland spezialisiert. Wir beherrschen nicht nur jedes Detail des deutschen Finanzsystems, sondern erklären jeden Begriff klar in Ihrer vertrauten Sprache und Denkweise, damit Sie die klügsten finanziellen Entscheidungen treffen.",
      p3: "Unsere Mission ist es, Ihr Finanzpartner in Deutschland zu sein, wo Sprache keine Barriere mehr ist und komplexe finanzielle Entscheidungen einfach und transparent werden.",
      consultantTitle: "Ihr persönlicher Berater",
      consultantName: "[Beratername]",
      consultantRole: "Senior Finanzberater",
      consultantBio1: "[Berater-Bio hier hinzufügen...]",
      consultantBio2: "[Ausbildung, Erfahrung, Qualifikationen...]",
      expertise: "Fachgebiete:",
      expertiseAreas: ["Private Krankenversicherung", "Immobilienfinanzierung", "Altersvorsorge", "Gewerbeversicherung"],
      valuesTitle: "Unsere Kernwerte",
      values: {
        professional: { title: "Professionell", desc: "Tiefe Expertise in deutschen Finanzmärkten mit relevanten Qualifikationen." },
        crossCultural: { title: "Interkulturell", desc: "Verständnis kultureller Unterschiede zwischen China und Deutschland." },
        integrity: { title: "Integrität", desc: "Kundeninteressen zuerst mit transparenter, ehrlicher Beratung." },
        caring: { title: "Fürsorglich", desc: "Persönliche Eins-zu-eins-Betreuung, von der Beratung bis zur Schadensabwicklung." }
      },
      ctaTitle: "Lassen Sie uns ins Gespräch kommen",
      ctaDesc: "Ob Sie neu in Deutschland sind oder schon Jahre hier leben – wir freuen uns darauf, Sie kennenzulernen und Sie professionell bei Ihrer Finanzplanung zu unterstützen.",
      ctaBtn: "Beratung buchen"
    },
    contact: {
      title: "Kontakt",
      subtitle: "Wir freuen uns darauf, Sie kennenzulernen und Sie professionell bei Ihrer Finanzplanung zu unterstützen.",
      formTitle: "Private Beratung buchen",
      formSubtitle: "Bitte füllen Sie die folgenden Informationen aus und wir werden Sie in Kürze kontaktieren.",
      name: "Name",
      namePlaceholder: "Ihr Name",
      phone: "Telefon",
      phonePlaceholder: "+49 ...",
      email: "E-Mail",
      emailPlaceholder: "beispiel@email.com",
      service: "Interessierte Dienstleistung",
      servicePlaceholder: "Dienstleistung auswählen",
      serviceOptions: {
        private_health: "Private Krankenversicherung",
        mortgage: "Immobilienfinanzierung",
        pension: "Altersvorsorge",
        corporate: "Gewerbeversicherung",
        other: "Sonstige Anfrage"
      },
      message: "Nachricht",
      messagePlaceholder: "Bitte beschreiben Sie Ihre Bedürfnisse oder Fragen...",
      privacyConsent: "Ich habe die gelesen und stimme der zu",
      privacyPolicy: "Datenschutzerklärung",
      disclaimerConsent: "Ich habe den gelesen und bestätige den",
      disclaimer: "Haftungsausschluss",
      riskWarning: "und Risikohinweis",
      submit: "Anfrage senden",
      submitting: "Wird gesendet...",
      required: "*",
      callTitle: "Rufen Sie uns an",
      callHours: "Montag - Freitag 9:00 - 17:00",
      emailTitle: "E-Mail senden",
      emailDesc: "Wir antworten schnellstmöglich auf Ihre Anfrage",
      locationTitle: "Bürostandort"
    },
    footer: {
      description: "Spezialisiert auf die Betreuung vermögender chinesischer Kunden in Deutschland, erklären wir komplexe deutsche Finanzsysteme in Ihrer Muttersprache.",
      quickLinks: "Schnelllinks",
      legalInfo: "Rechtliche Informationen",
      impressum: "Impressum",
      datenschutz: "Datenschutzerklärung",
      contactInfo: "Kontaktinformationen",
      location: "Deutschland",
      phoneNumber: "Wird aktualisiert",
      riskWarning: "Risikohinweis:",
      riskWarningText: "Geldanlagen sind mit Risiken verbunden. Die Informationen auf dieser Website dienen nur zu Informationszwecken und stellen keine Rechts-, Steuer- oder Anlageberatung dar. Bitte konsultieren Sie einen professionellen Berater, bevor Sie finanzielle Entscheidungen treffen.",
      copyright: "© {year} Finovance Consulting. Alle Rechte vorbehalten."
    },
    common: {
      learnMore: "Mehr erfahren"
    }
  }
};
