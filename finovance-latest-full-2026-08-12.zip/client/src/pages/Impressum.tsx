import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Impressum() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow bg-white">
        <div className="bg-primary py-16 text-center text-white">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-serif font-bold">Impressum</h1>
            <p className="text-primary-foreground/80 mt-2">法律声明</p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-12 max-w-3xl">
          <div className="prose prose-slate max-w-none">
            <h2 className="text-2xl font-serif font-bold text-primary mb-4">Angaben gemäß § 5 TMG</h2>
            
            <p className="text-muted-foreground mb-6">
              <strong>Finovance Consulting</strong><br />
              [公司地址待更新]<br />
              [城市，邮编]<br />
              Deutschland
            </p>

            <h3 className="text-xl font-bold text-primary mt-8 mb-3">Kontakt / 联系方式</h3>
            <p className="text-muted-foreground mb-6">
              Telefon: [待更新]<br />
              E-Mail: info@finovance.de
            </p>

            <h3 className="text-xl font-bold text-primary mt-8 mb-3">Berufsbezeichnung und berufsrechtliche Regelungen</h3>
            <p className="text-muted-foreground mb-6">
              [执照信息待更新，如 §34d, §34i, §34f GewO 等相关资质]
            </p>

            <h3 className="text-xl font-bold text-primary mt-8 mb-3">Haftungsausschluss / 免责声明</h3>
            <p className="text-muted-foreground mb-4">
              <strong>Haftung für Inhalte:</strong><br />
              作为服务提供商，我们根据德国电信媒体法（TMG）第 7 条第 1 款对本网站上的自有内容负责。
              然而，根据 TMG 第 8 至 10 条的规定，作为服务提供商，我们没有义务监控传输或存储的第三方信息，
              或调查表明非法活动的情况。
            </p>
            <p className="text-muted-foreground mb-6">
              本网站提供的信息仅供一般参考，不构成法律、税务或投资建议。在做出任何财务决策之前，
              请咨询专业顾问。
            </p>

            <h3 className="text-xl font-bold text-primary mt-8 mb-3">Urheberrecht / 版权声明</h3>
            <p className="text-muted-foreground">
              本网站上的内容和作品受德国版权法保护。在版权法范围之外复制、编辑、分发和任何形式的利用，
              均需获得相关作者或创作者的书面同意。
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
