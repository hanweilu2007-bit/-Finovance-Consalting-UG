import { motion } from "framer-motion";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ServiceCard } from "@/components/ServiceCard";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Landmark, Briefcase, PiggyBank, CheckCircle2 } from "lucide-react";
import { Link } from "wouter";
import { useI18n } from "@/lib/i18n";

const serviceIcons = [
  <ShieldCheck key="health" className="w-7 h-7" />,
  <Landmark key="mortgage" className="w-7 h-7" />,
  <PiggyBank key="pension" className="w-7 h-7" />,
  <Briefcase key="corporate" className="w-7 h-7" />,
];

export default function Home() {
  const { t, tArray } = useI18n();

  const whyUsItems = tArray<string>("home.whyUsItems");
  const serviceCards = tArray<{ title: string; description: string }>("home.serviceCards");

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow">
        <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden py-20">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&q=80&w=2000" 
              alt="Financial Consultation" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-primary/85 mix-blend-multiply" />
          </div>

          <div className="container relative z-10 px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
                {t("home.heroTitle")}<br className="hidden md:block" />
                <span className="text-secondary">{t("home.heroHighlight")}</span>
              </h1>
              <p className="text-lg sm:text-xl md:text-2xl text-white/90 mb-4 max-w-3xl mx-auto font-light">
                {t("home.heroSubtitle")}
              </p>
              <p className="text-base sm:text-lg text-white/70 mb-10 max-w-2xl mx-auto">
                {t("home.heroDescription")}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/contact">
                  <Button size="lg" className="bg-secondary text-primary hover:bg-secondary/90 text-base sm:text-lg px-6 sm:px-8 h-12 sm:h-14 font-bold w-full sm:w-auto" data-testid="button-hero-consult">
                    {t("home.consultBtn")}
                  </Button>
                </Link>
                <Link href="/services">
                  <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-primary text-base sm:text-lg px-6 sm:px-8 h-12 sm:h-14 w-full sm:w-auto" data-testid="button-hero-services">
                    {t("home.learnMore")}
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-white">
          <div className="container mx-auto px-4 text-center max-w-4xl">
            <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-6">{t("home.tagline")}</h2>
            <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
              {t("home.taglineDesc")}
            </p>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 md:mb-16">
              <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-4">{t("home.coreServices")}</h2>
              <div className="w-20 h-1 bg-secondary mx-auto rounded-full" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {serviceCards.map((card, index) => (
                <ServiceCard
                  key={index}
                  title={card.title}
                  description={card.description}
                  icon={serviceIcons[index]}
                  link="/services"
                />
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-primary text-white overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-secondary">{t("home.whyUs")}</h2>
                <div className="space-y-4 sm:space-y-6">
                  {whyUsItems.map((item, index) => (
                    <motion.div 
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center gap-4"
                    >
                      <div className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-secondary" />
                      </div>
                      <span className="text-base sm:text-lg font-light">{item}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
              <div className="relative hidden lg:block">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=1000" 
                  alt="Data Analysis" 
                  className="rounded-2xl shadow-2xl border-4 border-white/10"
                />
                <div className="absolute -bottom-6 -left-6 w-48 h-48 bg-secondary rounded-full mix-blend-multiply filter blur-3xl opacity-50" />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24 bg-white text-center">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-6">{t("home.ctaTitle")}</h2>
            <p className="text-lg sm:text-xl text-muted-foreground mb-10">
              {t("home.ctaDesc")}
            </p>
            <Link href="/contact">
              <Button size="lg" className="bg-primary text-white hover:bg-primary/90 h-12 sm:h-14 px-8 sm:px-10 text-base sm:text-lg shadow-lg shadow-primary/20" data-testid="button-cta-consult">
                {t("home.ctaBtn")}
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
