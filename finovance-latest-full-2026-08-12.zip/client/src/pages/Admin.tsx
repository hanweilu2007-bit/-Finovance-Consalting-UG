import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Plus, Upload, FileText, Lock, LogOut } from "lucide-react";

interface KnowledgeBaseItem {
  id: number;
  title: string;
  content: string;
  category: string;
  keywords: string[] | null;
  isActive: boolean;
  createdAt: string;
}

export default function Admin() {
  const { toast } = useToast();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const [adminSecret, setAdminSecret] = useState("");
  
  const [newItem, setNewItem] = useState({
    title: "",
    content: "",
    category: "",
    keywords: "",
  });
  
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadCategory, setUploadCategory] = useState("");

  useEffect(() => {
    let active = true;
    fetch("/api/admin/session")
      .then((response) => response.json())
      .then((data) => {
        if (active) setIsAuthenticated(Boolean(data.authenticated));
      })
      .catch(() => {
        if (active) setIsAuthenticated(false);
      })
      .finally(() => {
        if (active) setAuthChecked(true);
      });

    return () => {
      active = false;
    };
  }, []);

  const handleUnauthorized = (response: Response) => {
    if (response.status === 401) {
      setIsAuthenticated(false);
      queryClient.clear();
    }
  };

  const { data: items = [], isLoading } = useQuery<KnowledgeBaseItem[]>({
    queryKey: ["/api/admin/knowledge-base"],
    enabled: isAuthenticated,
    queryFn: async () => {
      const res = await fetch("/api/admin/knowledge-base");
      handleUnauthorized(res);
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof newItem) => {
      const res = await fetch("/api/admin/knowledge-base", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      handleUnauthorized(res);
      if (!res.ok) throw new Error("Failed to create");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/knowledge-base"] });
      setNewItem({ title: "", content: "", category: "", keywords: "" });
      toast({ title: "添加成功", description: "知识库条目已添加" });
    },
    onError: () => {
      toast({ title: "添加失败", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const confirmed = window.confirm("确定要删除这条知识库内容吗？删除后无法恢复。");
      if (!confirmed) return false;

      const res = await fetch(`/api/admin/knowledge-base/${id}`, {
        method: "DELETE",
      });
      handleUnauthorized(res);
      if (!res.ok) throw new Error("Failed to delete");
      return true;
    },
    onSuccess: (deleted) => {
      if (!deleted) return;
      queryClient.invalidateQueries({ queryKey: ["/api/admin/knowledge-base"] });
      toast({ title: "删除成功" });
    },
    onError: () => {
      toast({ title: "删除失败", variant: "destructive" });
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!uploadFile || !uploadCategory) return;
      const formData = new FormData();
      formData.append("file", uploadFile);
      formData.append("category", uploadCategory);
      
      const res = await fetch("/api/admin/knowledge-base/upload", {
        method: "POST",
        body: formData,
      });
      handleUnauthorized(res);
      if (!res.ok) throw new Error("Failed to upload");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/knowledge-base"] });
      setUploadFile(null);
      setUploadCategory("");
      toast({ title: "上传成功", description: "文件内容已添加到知识库" });
    },
    onError: () => {
      toast({ title: "上传失败", variant: "destructive" });
    },
  });

  const handleLogin = async () => {
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ secret: adminSecret }),
      });
      if (res.ok) {
        setIsAuthenticated(true);
        setAdminSecret("");
        toast({ title: "登录成功" });
      } else if (res.status === 429) {
        toast({ title: "尝试次数过多", description: "请稍后再试", variant: "destructive" });
      } else {
        toast({ title: "认证失败", description: "请检查管理员密钥", variant: "destructive" });
      }
    } catch {
      toast({ title: "连接失败", variant: "destructive" });
    }
  };

  const handleLogout = async () => {
    await fetch("/api/admin/logout", { method: "POST" }).catch(() => undefined);
    queryClient.clear();
    setIsAuthenticated(false);
    toast({ title: "已安全退出" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.title || !newItem.content || !newItem.category) {
      toast({ title: "请填写必填字段", variant: "destructive" });
      return;
    }
    createMutation.mutate(newItem);
  };

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFile || !uploadCategory) {
      toast({ title: "请选择文件和分类", variant: "destructive" });
      return;
    }
    uploadMutation.mutate();
  };

  if (!authChecked) {
    return <div className="min-h-screen bg-background flex items-center justify-center">正在检查登录状态...</div>;
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              知识库管理登录
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>管理员密钥</Label>
              <Input
                type="password"
                value={adminSecret}
                onChange={(e) => setAdminSecret(e.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") handleLogin();
                }}
                placeholder="输入管理员密钥"
                autoComplete="current-password"
                data-testid="input-admin-token"
              />
            </div>
            <Button onClick={handleLogin} className="w-full" data-testid="button-admin-login">
              登录
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between gap-4">
          <h1 className="text-3xl font-bold">知识库管理</h1>
          <Button variant="outline" onClick={handleLogout} className="gap-2">
            <LogOut className="w-4 h-4" />
            安全退出
          </Button>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Add new item form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                添加知识条目
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>标题 *</Label>
                  <Input
                    value={newItem.title}
                    onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                    placeholder="例如：什么是私人医疗保险？"
                    data-testid="input-kb-title"
                  />
                </div>
                <div className="space-y-2">
                  <Label>分类 *</Label>
                  <Input
                    value={newItem.category}
                    onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                    placeholder="例如：私人医疗保险、购房贷款"
                    data-testid="input-kb-category"
                  />
                </div>
                <div className="space-y-2">
                  <Label>内容 *</Label>
                  <Textarea
                    value={newItem.content}
                    onChange={(e) => setNewItem({ ...newItem, content: e.target.value })}
                    placeholder="详细内容..."
                    rows={5}
                    data-testid="input-kb-content"
                  />
                </div>
                <div className="space-y-2">
                  <Label>关键词（可选，用逗号分隔）</Label>
                  <Input
                    value={newItem.keywords}
                    onChange={(e) => setNewItem({ ...newItem, keywords: e.target.value })}
                    placeholder="PKV, 保险, 德国"
                    data-testid="input-kb-keywords"
                  />
                </div>
                <Button type="submit" disabled={createMutation.isPending} data-testid="button-kb-submit">
                  {createMutation.isPending ? "添加中..." : "添加条目"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* File upload */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                上传文件
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleUpload} className="space-y-4">
                <div className="space-y-2">
                  <Label>选择文件 (TXT / PDF)</Label>
                  <Input
                    type="file"
                    accept=".txt,.pdf"
                    onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                    data-testid="input-file-upload"
                  />
                  {uploadFile && (
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <FileText className="w-4 h-4" />
                      {uploadFile.name}
                    </p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label>分类 *</Label>
                  <Input
                    value={uploadCategory}
                    onChange={(e) => setUploadCategory(e.target.value)}
                    placeholder="例如：公司介绍"
                    data-testid="input-upload-category"
                  />
                </div>
                <Button type="submit" disabled={uploadMutation.isPending || !uploadFile} data-testid="button-upload-submit">
                  {uploadMutation.isPending ? "上传中..." : "上传文件"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Existing items */}
        <Card>
          <CardHeader>
            <CardTitle>现有知识库条目 ({items.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-muted-foreground">加载中...</p>
            ) : items.length === 0 ? (
              <p className="text-muted-foreground">暂无知识库条目</p>
            ) : (
              <div className="space-y-4">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="border rounded-lg p-4 flex justify-between items-start gap-4"
                    data-testid={`kb-item-${item.id}`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold">{item.title}</h3>
                        <span className="text-xs bg-secondary px-2 py-0.5 rounded">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {item.content}
                      </p>
                      {item.keywords && item.keywords.length > 0 && (
                        <p className="text-xs text-muted-foreground mt-1">
                          关键词: {item.keywords.join(", ")}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(item.id)}
                      disabled={deleteMutation.isPending}
                      data-testid={`button-delete-${item.id}`}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
