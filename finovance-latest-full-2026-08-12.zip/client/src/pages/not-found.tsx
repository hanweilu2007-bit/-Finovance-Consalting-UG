import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-slate-50">
      <Card className="w-full max-w-md mx-4 shadow-xl border-border">
        <CardContent className="pt-6 text-center">
          <div className="flex mb-4 justify-center">
            <AlertCircle className="h-16 w-16 text-destructive" />
          </div>
          
          <h1 className="text-2xl font-bold text-primary mb-2">页面未找到 (404)</h1>
          <p className="text-muted-foreground mb-6">
            抱歉，您访问的页面不存在或已被移除。
          </p>
          
          <Link href="/">
            <Button className="w-full bg-secondary text-primary font-bold hover:bg-secondary/90">
              返回首页
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
