import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ContactForm } from "@/components/ContactForm";
import { Mail, Phone, MapPin } from "lucide-react";
import { useI18n } from "@/lib/i18n";

export default function Contact() {
  const { t } = useI18n();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      <main className="flex-grow">
        <div className="bg-primary py-16 md:py-20 text-center text-white">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl sm:text-4xl font-bold mb-4">{t("contact.title")}</h1>
            <p className="text-base sm:text-lg text-primary-foreground/80 max-w-2xl mx-auto">
              {t("contact.subtitle")}
            </p>
          </div>
        </div>

        <div className="container mx-auto px-4 -mt-10 mb-16 md:mb-20 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
            <div className="lg:col-span-1 space-y-4 md:space-y-6">
              <div className="bg-white p-4 sm:p-6 rounded-xl shadow-lg border border-border flex items-start gap-4">
                <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center shrink-0 text-primary">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-primary mb-1">{t("contact.callTitle")}</h3>
                  <p className="text-sm text-muted-foreground mb-1">{t("contact.callHours")}</p>
                  <p className="text-lg font-semibold text-secondary">{t("footer.phoneNumber")}</p>
                </div>
              </div>

              <div className="bg-white p-4 sm:p-6 rounded-xl shadow-lg border border-border flex items-start gap-4">
                <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center shrink-0 text-primary">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-primary mb-1">{t("contact.emailTitle")}</h3>
                  <p className="text-sm text-muted-foreground mb-1">{t("contact.emailDesc")}</p>
                  <p className="font-semibold text-primary">info@finovance.de</p>
                </div>
              </div>

              <div className="bg-white p-4 sm:p-6 rounded-xl shadow-lg border border-border flex items-start gap-4">
                <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center shrink-0 text-primary">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-primary mb-1">{t("contact.locationTitle")}</h3>
                  <p className="text-sm text-muted-foreground">
                    {t("footer.location")}
                  </p>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2">
              <ContactForm />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
