import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ShieldCheck, Landmark, PiggyBank, Briefcase, ChevronRight } from "lucide-react";
import { useI18n } from "@/lib/i18n";

export default function Services() {
  const { t, tArray } = useI18n();

  const privateHealthFeatures = tArray<{ title: string; desc: string }>("services.privateHealth.features");
  const mortgageFeatures = tArray<{ title: string; desc: string }>("services.mortgage.features");
  const pensionFeatures = tArray<{ title: string; desc: string }>("services.pension.features");
  const corporateFeatures = tArray<{ title: string; desc: string }>("services.corporate.features");

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />
      
      <main className="flex-grow">
        <div className="bg-primary py-16 md:py-20 text-center text-white">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl sm:text-4xl font-bold mb-4">{t("services.title")}</h1>
            <p className="text-base sm:text-lg text-primary-foreground/80 max-w-2xl mx-auto">
              {t("services.subtitle")}
            </p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-12 md:py-16 space-y-16 md:space-y-24">
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100 text-primary font-semibold mb-6 text-sm">
                <ShieldCheck className="w-5 h-5" /> {t("services.privateHealth.tag")}
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-6">{t("services.privateHealth.title")}</h2>
              <p className="text-muted-foreground mb-6 leading-relaxed text-sm sm:text-base">
                {t("services.privateHealth.description")}
              </p>
              <ul className="space-y-4 mb-8">
                {privateHealthFeatures.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-secondary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <ChevronRight className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <strong className="text-primary block">{feature.title}</strong>
                      <span className="text-sm text-muted-foreground">{feature.desc}</span>
                    </div>
                  </li>
                ))}
              </ul>
              <Link href="/contact">
                <Button className="bg-secondary text-primary hover:bg-secondary/90" data-testid="button-service-health">
                  {t("services.privateHealth.cta")}
                </Button>
              </Link>
            </div>
            <div className="order-1 lg:order-2">
              <img 
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=1000" 
                alt="Private Health Insurance" 
                className="rounded-2xl shadow-xl border border-border w-full"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="order-1">
              <img 
                src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=1000" 
                alt="Mortgage" 
                className="rounded-2xl shadow-xl border border-border w-full"
              />
            </div>
            <div className="order-2">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-100 text-amber-800 font-semibold mb-6 text-sm">
                <Landmark className="w-5 h-5" /> {t("services.mortgage.tag")}
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-6">{t("services.mortgage.title")}</h2>
              <p className="text-muted-foreground mb-6 leading-relaxed text-sm sm:text-base">
                {t("services.mortgage.description")}
              </p>
              <ul className="space-y-4 mb-8">
                {mortgageFeatures.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-secondary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <ChevronRight className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <strong className="text-primary block">{feature.title}</strong>
                      <span className="text-sm text-muted-foreground">{feature.desc}</span>
                    </div>
                  </li>
                ))}
              </ul>
              <Link href="/contact">
                <Button className="bg-secondary text-primary hover:bg-secondary/90" data-testid="button-service-mortgage">
                  {t("services.mortgage.cta")}
                </Button>
              </Link>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-100 text-green-800 font-semibold mb-6 text-sm">
                <PiggyBank className="w-5 h-5" /> {t("services.pension.tag")}
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-6">{t("services.pension.title")}</h2>
              <p className="text-muted-foreground mb-6 leading-relaxed text-sm sm:text-base">
                {t("services.pension.description")}
              </p>
              <ul className="space-y-4 mb-8">
                {pensionFeatures.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-secondary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <ChevronRight className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <strong className="text-primary block">{feature.title}</strong>
                      <span className="text-sm text-muted-foreground">{feature.desc}</span>
                    </div>
                  </li>
                ))}
              </ul>
              <Link href="/contact">
                <Button className="bg-secondary text-primary hover:bg-secondary/90" data-testid="button-service-pension">
                  {t("services.pension.cta")}
                </Button>
              </Link>
            </div>
            <div className="order-1 lg:order-2">
              <img 
                src="https://images.unsplash.com/photo-1579532537598-459ecdaf39cc?auto=format&fit=crop&q=80&w=1000" 
                alt="Pension Planning" 
                className="rounded-2xl shadow-xl border border-border w-full"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="order-1">
              <img 
                src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1000" 
                alt="Corporate Insurance" 
                className="rounded-2xl shadow-xl border border-border w-full"
              />
            </div>
            <div className="order-2">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-100 text-purple-800 font-semibold mb-6 text-sm">
                <Briefcase className="w-5 h-5" /> {t("services.corporate.tag")}
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-6">{t("services.corporate.title")}</h2>
              <p className="text-muted-foreground mb-6 leading-relaxed text-sm sm:text-base">
                {t("services.corporate.description")}
              </p>
              <ul className="space-y-4 mb-8">
                {corporateFeatures.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-secondary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <ChevronRight className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <strong className="text-primary block">{feature.title}</strong>
                      <span className="text-sm text-muted-foreground">{feature.desc}</span>
                    </div>
                  </li>
                ))}
              </ul>
              <Link href="/contact">
                <Button className="bg-secondary text-primary hover:bg-secondary/90" data-testid="button-service-corporate">
                  {t("services.corporate.cta")}
                </Button>
              </Link>
            </div>
          </div>

        </div>
      </main>

      <Footer />
    </div>
  );
}
