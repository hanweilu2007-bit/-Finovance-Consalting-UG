import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Award, Users, Globe, Heart } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import consultantPhoto from "@assets/Foto_1770237058474.jpg";

export default function About() {
  const { t, tArray, tObject } = useI18n();

  const expertiseAreas = tArray<string>("about.expertiseAreas");
  const values = tObject<Record<string, { title: string; desc: string }>>("about.values");

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow">
        <div className="bg-primary py-16 md:py-20 text-center text-white">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl sm:text-4xl font-bold mb-4">{t("about.title")}</h1>
            <p className="text-base sm:text-lg text-primary-foreground/80 max-w-2xl mx-auto">
              {t("about.subtitle")}
            </p>
          </div>
        </div>

        <section className="py-16 md:py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-6">{t("about.sectionTitle")}</h2>
                <p className="text-muted-foreground mb-6 leading-relaxed text-sm sm:text-base">
                  {t("about.p1")}
                </p>
                <p className="text-muted-foreground mb-6 leading-relaxed text-sm sm:text-base">
                  {t("about.p2")}
                </p>
                <p className="text-muted-foreground leading-relaxed text-sm sm:text-base">
                  {t("about.p3")}
                </p>
              </div>
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&q=80&w=1000" 
                  alt="Professional Consultation" 
                  className="rounded-2xl shadow-xl w-full"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 md:mb-16">
              <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-4">{t("about.consultantTitle")}</h2>
              <div className="w-20 h-1 bg-secondary mx-auto rounded-full" />
            </div>

            <div className="max-w-4xl mx-auto">
              <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-2">
                  <div className="relative">
                    <img 
                      src={consultantPhoto} 
                      alt={t("about.consultantRole")} 
                      className="w-full h-full object-cover min-h-[300px] md:min-h-[400px]"
                    />
                  </div>
                  <div className="p-6 sm:p-8 md:p-10 flex flex-col justify-center">
                    <h3 className="text-xl sm:text-2xl font-bold text-primary mb-2">
                      {t("about.consultantName")}
                    </h3>
                    <p className="text-secondary font-medium mb-6">{t("about.consultantRole")}</p>
                    
                    <div className="space-y-4 text-muted-foreground text-sm sm:text-base">
                      <p className="leading-relaxed">
                        {t("about.consultantBio1")}
                      </p>
                      <p className="leading-relaxed">
                        {t("about.consultantBio2")}
                      </p>
                    </div>

                    <div className="mt-8 pt-6 border-t border-border">
                      <p className="text-sm text-muted-foreground mb-3">{t("about.expertise")}</p>
                      <div className="flex flex-wrap gap-2">
                        {expertiseAreas.map((area, idx) => (
                          <span key={idx} className="px-3 py-1 bg-primary/10 text-primary text-xs sm:text-sm rounded-full">
                            {area}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 md:mb-16">
              <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-4">{t("about.valuesTitle")}</h2>
              <div className="w-20 h-1 bg-secondary mx-auto rounded-full" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              <div className="bg-slate-50 p-6 rounded-xl shadow-md text-center">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-bold text-primary mb-2">{values.professional?.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {values.professional?.desc}
                </p>
              </div>

              <div className="bg-slate-50 p-6 rounded-xl shadow-md text-center">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-bold text-primary mb-2">{values.crossCultural?.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {values.crossCultural?.desc}
                </p>
              </div>

              <div className="bg-slate-50 p-6 rounded-xl shadow-md text-center">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-bold text-primary mb-2">{values.integrity?.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {values.integrity?.desc}
                </p>
              </div>

              <div className="bg-slate-50 p-6 rounded-xl shadow-md text-center">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-bold text-primary mb-2">{values.caring?.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {values.caring?.desc}
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24 bg-primary text-center text-white">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-secondary">{t("about.ctaTitle")}</h2>
            <p className="text-lg sm:text-xl text-white/80 mb-10 max-w-2xl mx-auto">
              {t("about.ctaDesc")}
            </p>
            <Link href="/contact">
              <Button size="lg" className="bg-secondary text-primary hover:bg-secondary/90 h-12 sm:h-14 px-8 sm:px-10 text-base sm:text-lg font-bold" data-testid="button-about-consult">
                {t("about.ctaBtn")}
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
