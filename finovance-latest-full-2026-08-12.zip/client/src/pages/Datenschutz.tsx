import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Datenschutz() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow bg-white">
        <div className="bg-primary py-16 text-center text-white">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-serif font-bold">Datenschutzerklärung</h1>
            <p className="text-primary-foreground/80 mt-2">隐私政策</p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-12 max-w-3xl">
          <div className="prose prose-slate max-w-none">
            <h2 className="text-2xl font-serif font-bold text-primary mb-4">1. Datenschutz auf einen Blick / 隐私保护概览</h2>
            
            <h3 className="text-xl font-bold text-primary mt-6 mb-3">Allgemeine Hinweise / 一般说明</h3>
            <p className="text-muted-foreground mb-6">
              以下说明简要概述了当您访问本网站时您的个人数据会发生什么。个人数据是指可以用来识别您个人身份的所有数据。
              有关数据保护主题的详细信息，请参阅本文下方列出的我们的隐私政策。
            </p>

            <h3 className="text-xl font-bold text-primary mt-6 mb-3">Datenerfassung auf dieser Website / 本网站的数据收集</h3>
            <p className="text-muted-foreground mb-4">
              <strong>谁负责本网站的数据收集？</strong><br />
              本网站的数据处理由网站运营商进行。您可以在本网站的 Impressum（法律声明）中找到其联系方式。
            </p>
            <p className="text-muted-foreground mb-6">
              <strong>我们如何收集您的数据？</strong><br />
              一方面，当您向我们提供数据时，我们会收集这些数据。例如，这可能是您在联系表单中输入的数据。
              另一方面，当您访问网站时，我们的 IT 系统会自动收集其他数据。这主要是技术数据（例如，互联网浏览器、操作系统或页面访问时间）。
              这些数据在您进入本网站时会自动收集。
            </p>

            <h2 className="text-2xl font-serif font-bold text-primary mt-10 mb-4">2. Hosting</h2>
            <p className="text-muted-foreground mb-6">
              本网站托管于外部服务提供商（Hoster）。在本网站上收集的个人数据存储在托管商的服务器上。
              这可能包括 IP 地址、联系请求、元数据和通信数据、合同数据、联系方式、姓名、网站访问和其他通过网站生成的数据。
            </p>

            <h2 className="text-2xl font-serif font-bold text-primary mt-10 mb-4">3. Allgemeine Hinweise und Pflichtinformationen / 一般说明和必要信息</h2>
            
            <h3 className="text-xl font-bold text-primary mt-6 mb-3">Datenschutz / 数据保护</h3>
            <p className="text-muted-foreground mb-6">
              本网站的运营商非常重视保护您的个人数据。我们根据法定数据保护条例和本隐私政策对您的个人数据进行保密处理。
            </p>

            <h3 className="text-xl font-bold text-primary mt-6 mb-3">Ihre Rechte / 您的权利</h3>
            <p className="text-muted-foreground mb-4">
              根据 GDPR（通用数据保护条例），您享有以下权利：
            </p>
            <ul className="list-disc pl-6 text-muted-foreground mb-6 space-y-2">
              <li>查阅权 (Art. 15 DSGVO)</li>
              <li>更正权 (Art. 16 DSGVO)</li>
              <li>删除权 / "被遗忘权" (Art. 17 DSGVO)</li>
              <li>限制处理权 (Art. 18 DSGVO)</li>
              <li>数据可携带权 (Art. 20 DSGVO)</li>
              <li>反对权 (Art. 21 DSGVO)</li>
            </ul>

            <h2 className="text-2xl font-serif font-bold text-primary mt-10 mb-4">4. Datenerfassung auf dieser Website / 本网站的数据收集</h2>
            
            <h3 className="text-xl font-bold text-primary mt-6 mb-3">Anfrage per E-Mail oder Kontaktformular / 通过电子邮件或联系表单的咨询</h3>
            <p className="text-muted-foreground mb-6">
              如果您通过电子邮件或联系表单与我们联系，您的咨询（包括所有由此产生的个人数据，如姓名、电话、邮箱、咨询内容）
              将被我们存储和处理，以便处理您的请求。未经您的同意，我们不会传递这些数据。
              这些数据的处理基于 GDPR 第 6 条第 1 款 b 项（合同履行或合同前措施）。
            </p>

            <h3 className="text-xl font-bold text-primary mt-6 mb-3">数据保留期限</h3>
            <p className="text-muted-foreground">
              您通过联系表单提交的数据将保留至您要求我们删除、撤销您对存储的同意或数据存储的目的不再适用
              （例如，在您的请求处理完成后）。强制性法定条款，特别是保留期限，不受影响。
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
