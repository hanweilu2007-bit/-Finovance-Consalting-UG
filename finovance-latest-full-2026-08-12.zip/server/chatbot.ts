import type { Express, Request, Response, NextFunction } from "express";
import OpenAI from "openai";
import { z } from "zod";
import multer from "multer";
import { createRequire } from "module";
import { db } from "./db";
import { conversations, messages, knowledgeBase, type Conversation } from "@shared/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import nodemailer from "nodemailer";
import { createRateLimiter, getClientIp, safeSecretEquals } from "./security";

const require = createRequire(import.meta.url);
const pdfParse = require("pdf-parse");

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowedTypes = ["text/plain", "application/pdf"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only .txt and .pdf files are allowed"));
    }
  },
});

const openai = process.env.AI_INTEGRATIONS_OPENAI_API_KEY
  ? new OpenAI({
      apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
      baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
    })
  : null;

const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-5.2";
const HUMAN_HANDOFF_EMAIL = process.env.HUMAN_HANDOFF_EMAIL;
const ADMIN_SECRET = process.env.ADMIN_SECRET;
const ADMIN_SESSION_MAX_AGE = 8 * 60 * 60 * 1000;

if (!ADMIN_SECRET) {
  console.warn("WARNING: ADMIN_SECRET is not set. Admin routes will be inaccessible.");
}
if (!openai) {
  console.warn("WARNING: OpenAI API key is not set. AI chatbot responses are disabled.");
}
if (!HUMAN_HANDOFF_EMAIL) {
  console.warn("WARNING: HUMAN_HANDOFF_EMAIL is not set. Human handoff emails are disabled.");
}

const sessionSchema = z.object({
  sessionId: z.string().min(16).max(100).regex(/^[A-Za-z0-9_-]+$/),
});

const messageSchema = z.object({
  conversationId: z.number().int().positive(),
  sessionId: z.string().min(16).max(100).regex(/^[A-Za-z0-9_-]+$/),
  content: z.string().trim().min(1).max(2000),
});

const adminLoginSchema = z.object({
  secret: z.string().min(1).max(256),
});

const knowledgeBaseSchema = z.object({
  title: z.string().trim().min(1).max(200),
  content: z.string().trim().min(1).max(10000),
  category: z.string().trim().min(1).max(100),
  keywords: z.string().optional().nullable(),
  isActive: z.boolean().optional(),
});

const uploadCategorySchema = z.string().trim().min(1).max(100);

const chatSessionLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 30,
  message: "Too many chat session requests. Please try again later.",
});

const chatIpLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: "Too many chat messages. Please try again later.",
});

const chatConversationLimiter = createRateLimiter({
  windowMs: 60 * 60 * 1000,
  max: 30,
  message: "This chat has reached its hourly message limit. Please try again later.",
  keyGenerator: (req) => `${getClientIp(req)}:${String(req.body?.sessionId || "unknown")}`,
});

const adminLoginLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: "Too many login attempts. Please try again later.",
});

function adminAuth(req: Request, res: Response, next: NextFunction) {
  const authenticatedAt = req.session.adminAuthenticatedAt || 0;
  const sessionExpired = Date.now() - authenticatedAt > ADMIN_SESSION_MAX_AGE;

  if (!req.session.isAdmin || sessionExpired) {
    req.session.isAdmin = false;
    req.session.adminAuthenticatedAt = undefined;
    return res.status(401).json({ error: "Unauthorized" });
  }

  next();
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>'"]/g, (character) => {
    const entities: Record<string, string> = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "'": "&#39;",
      '"': "&quot;",
    };
    return entities[character];
  });
}

function setSseHeaders(res: Response): void {
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
}

const SYSTEM_PROMPT = `你是Finovance Consulting的智能客服助手，专为在德华人提供金融咨询服务。

公司背景：
- Finovance Consulting专注于服务德国华人高净值客户
- 用中文母语为客户解读复杂的德国金融体系
- 核心服务包括：私人医疗保险(PKV)、购房贷款、养老保险、企业保险

你的职责：
1. 友好地欢迎客户，了解他们的需求
2. 根据知识库内容回答常见问题
3. 如果问题超出知识库范围或客户需要具体方案，礼貌地建议转接人工服务
4. 使用客户的语言回复（支持中文、英文、德语）
5. 不要给出保证收益、个性化投资结论或替代持牌顾问的正式建议

转人工的情况：
- 客户明确要求与人工沟通
- 问题涉及具体的个人情况或定制方案
- 知识库中没有相关答案
- 客户表达不满或投诉

回复风格：
- 专业但亲切
- 简洁明了
- 适当使用换行增加可读性`;

async function searchKnowledgeBase(query: string): Promise<string> {
  const keywords = query.toLowerCase().split(/\s+/).filter((keyword) => keyword.length > 1);
  if (keywords.length === 0) {
    return "";
  }

  const results = await db
    .select()
    .from(knowledgeBase)
    .where(eq(knowledgeBase.isActive, true))
    .orderBy(desc(knowledgeBase.updatedAt))
    .limit(50);

  const relevant = results
    .map((item) => {
      const searchable = `${item.title} ${item.content} ${item.category} ${(item.keywords || []).join(" ")}`.toLowerCase();
      const score = keywords.reduce((total, keyword) => total + (searchable.includes(keyword) ? 1 : 0), 0);
      return { item, score };
    })
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map(({ item }) => item);

  return relevant
    .map((item) => `【${item.category}】${item.title}\n${item.content}`)
    .join("\n\n---\n\n");
}

async function sendHumanHandoffEmail(conversation: Conversation, userMessage: string): Promise<void> {
  if (!HUMAN_HANDOFF_EMAIL || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    throw new Error("Human handoff email is not configured");
  }

  const smtpPort = Number.parseInt(process.env.SMTP_PORT || "587", 10);
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: smtpPort,
    secure: smtpPort === 465,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  const allMessages = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversation.id))
    .orderBy(messages.createdAt);

  const chatHistory = allMessages
    .map((message) => `[${message.role === "user" ? "客户" : "AI"}] ${message.content}`)
    .join("\n\n");

  const safeLatestMessage = escapeHtml(userMessage);
  const safeChatHistory = escapeHtml(chatHistory);

  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: HUMAN_HANDOFF_EMAIL,
    subject: `[Finovance] 客户请求人工服务 - 会话#${conversation.id}`,
    text: `客户请求转接人工服务\n\n会话ID: ${conversation.id}\n时间: ${new Date().toLocaleString("zh-CN", { timeZone: "Europe/Berlin" })}\n\n最新消息: ${userMessage}\n\n完整对话记录:\n${chatHistory}\n\n请尽快与客户联系。`,
    html: `<h2>客户请求转接人工服务</h2>
<p><strong>会话ID:</strong> ${conversation.id}</p>
<p><strong>时间:</strong> ${new Date().toLocaleString("zh-CN", { timeZone: "Europe/Berlin" })}</p>
<p><strong>最新消息:</strong> ${safeLatestMessage}</p>
<hr>
<h3>完整对话记录:</h3>
<pre style="background:#f5f5f5;padding:15px;border-radius:5px;white-space:pre-wrap;">${safeChatHistory}</pre>
<hr>
<p>请尽快与客户联系。</p>`,
  });
}

export function registerChatbotRoutes(app: Express): void {
  app.post("/api/admin/login", adminLoginLimiter, async (req: Request, res: Response) => {
    const parsed = adminLoginSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid login data" });
    }
    if (!ADMIN_SECRET) {
      return res.status(503).json({ error: "Admin functionality not configured" });
    }
    if (!safeSecretEquals(parsed.data.secret, ADMIN_SECRET)) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    await new Promise<void>((resolve, reject) => {
      req.session.regenerate((error) => {
        if (error) reject(error);
        else resolve();
      });
    });

    req.session.isAdmin = true;
    req.session.adminAuthenticatedAt = Date.now();
    return res.json({ authenticated: true });
  });

  app.get("/api/admin/session", (req: Request, res: Response) => {
    const authenticatedAt = req.session.adminAuthenticatedAt || 0;
    const authenticated = Boolean(req.session.isAdmin) && Date.now() - authenticatedAt <= ADMIN_SESSION_MAX_AGE;
    return res.json({ authenticated });
  });

  app.post("/api/admin/logout", (req: Request, res: Response) => {
    req.session.destroy(() => {
      res.clearCookie("finovance.sid", {
        httpOnly: true,
        sameSite: "strict",
        secure: process.env.NODE_ENV === "production",
      });
      res.status(204).end();
    });
  });

  // Get or create conversation by browser session identifier.
  app.post("/api/chatbot/session", chatSessionLimiter, async (req: Request, res: Response) => {
    try {
      const parsed = sessionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid session data" });
      }
      const { sessionId } = parsed.data;

      let [conversation] = await db
        .select()
        .from(conversations)
        .where(eq(conversations.sessionId, sessionId))
        .orderBy(desc(conversations.createdAt))
        .limit(1);

      if (!conversation) {
        [conversation] = await db
          .insert(conversations)
          .values({ title: "新对话", sessionId, status: "active" })
          .returning();
      }

      const chatMessages = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, conversation.id))
        .orderBy(messages.createdAt);

      return res.json({ conversation, messages: chatMessages });
    } catch (error) {
      console.error("Error managing chat session:", error instanceof Error ? error.message : "Unknown error");
      return res.status(500).json({ error: "Failed to manage session" });
    }
  });

  // Send message and get AI response (streaming).
  app.post(
    "/api/chatbot/message",
    chatIpLimiter,
    chatConversationLimiter,
    async (req: Request, res: Response) => {
      try {
        const parsed = messageSchema.safeParse(req.body);
        if (!parsed.success) {
          return res.status(400).json({ error: "Invalid message data" });
        }
        const { conversationId, sessionId, content } = parsed.data;

        const [conversation] = await db
          .select()
          .from(conversations)
          .where(and(eq(conversations.id, conversationId), eq(conversations.sessionId, sessionId)))
          .limit(1);

        if (!conversation) {
          return res.status(404).json({ error: "Conversation not found" });
        }

        await db.insert(messages).values({ conversationId, role: "user", content });
        await db
          .update(conversations)
          .set({ updatedAt: sql`CURRENT_TIMESTAMP` })
          .where(eq(conversations.id, conversationId));

        const handoffKeywords = ["人工", "真人", "客服", "转接", "human", "agent", "speak to someone", "mensch", "berater"];
        const normalizedContent = content.toLowerCase();
        const needsHandoff = handoffKeywords.some((keyword) => normalizedContent.includes(keyword));

        if (needsHandoff) {
          await db
            .update(conversations)
            .set({ status: "pending_human", updatedAt: sql`CURRENT_TIMESTAMP` })
            .where(eq(conversations.id, conversationId));

          try {
            await sendHumanHandoffEmail(conversation, content);
          } catch (emailError) {
            console.error("Failed to send handoff email:", emailError instanceof Error ? emailError.message : "Unknown error");
          }

          const handoffResponse = "好的，我已经记录了您的人工服务请求。我们的顾问会尽快处理。为保护您的隐私，请不要在聊天中发送密码、银行卡号或完整证件号码。";
          await db.insert(messages).values({ conversationId, role: "assistant", content: handoffResponse });

          setSseHeaders(res);
          res.write(`data: ${JSON.stringify({ content: handoffResponse })}\n\n`);
          res.write(`data: ${JSON.stringify({ done: true, handoff: true })}\n\n`);
          return res.end();
        }

        if (!openai) {
          return res.status(503).json({ error: "AI chatbot is temporarily unavailable" });
        }

        const [kbContext, recentMessagesDescending] = await Promise.all([
          searchKnowledgeBase(content),
          db
            .select()
            .from(messages)
            .where(eq(messages.conversationId, conversationId))
            .orderBy(desc(messages.createdAt))
            .limit(20),
        ]);

        const recentMessages = recentMessagesDescending.reverse();
        const chatHistory: OpenAI.ChatCompletionMessageParam[] = [
          {
            role: "system",
            content: SYSTEM_PROMPT + (kbContext ? `\n\n以下是相关知识库内容，请参考回答：\n${kbContext}` : ""),
          },
          ...recentMessages.map((message) => ({
            role: message.role as "user" | "assistant",
            content: message.content,
          })),
        ];

        setSseHeaders(res);

        const stream = await openai.chat.completions.create({
          model: OPENAI_MODEL,
          messages: chatHistory,
          stream: true,
          max_completion_tokens: 800,
        });

        let fullResponse = "";
        for await (const chunk of stream) {
          if (res.destroyed) break;
          const chunkContent = chunk.choices[0]?.delta?.content || "";
          if (chunkContent) {
            fullResponse += chunkContent;
            res.write(`data: ${JSON.stringify({ content: chunkContent })}\n\n`);
          }
        }

        if (fullResponse) {
          await db.insert(messages).values({ conversationId, role: "assistant", content: fullResponse });
        }

        if (!res.destroyed) {
          res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
          res.end();
        }
      } catch (error) {
        console.error("Error sending chat message:", error instanceof Error ? error.message : "Unknown error");
        if (res.headersSent) {
          res.write(`data: ${JSON.stringify({ error: "Failed to process message" })}\n\n`);
          return res.end();
        }
        return res.status(500).json({ error: "Failed to send message" });
      }
    },
  );

  // === KNOWLEDGE BASE ADMIN ROUTES ===
  app.get("/api/admin/knowledge-base", adminAuth, async (_req: Request, res: Response) => {
    try {
      const items = await db.select().from(knowledgeBase).orderBy(desc(knowledgeBase.createdAt));
      return res.json(items);
    } catch (error) {
      console.error("Error fetching knowledge base:", error instanceof Error ? error.message : "Unknown error");
      return res.status(500).json({ error: "Failed to fetch knowledge base" });
    }
  });

  app.post("/api/admin/knowledge-base", adminAuth, async (req: Request, res: Response) => {
    try {
      const parsed = knowledgeBaseSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid knowledge base data" });
      }
      const { title, content, category, keywords, isActive } = parsed.data;
      const keywordsArray = keywords
        ? keywords.split(",").map((keyword) => keyword.trim()).filter(Boolean)
        : [];

      const [item] = await db
        .insert(knowledgeBase)
        .values({ title, content, category, keywords: keywordsArray, isActive: isActive ?? true })
        .returning();

      return res.status(201).json(item);
    } catch (error) {
      console.error("Error creating knowledge base item:", error instanceof Error ? error.message : "Unknown error");
      return res.status(500).json({ error: "Failed to create knowledge base item" });
    }
  });

  app.post(
    "/api/admin/knowledge-base/upload",
    adminAuth,
    upload.single("file"),
    async (req: Request, res: Response) => {
      try {
        const file = req.file;
        const categoryResult = uploadCategorySchema.safeParse(req.body.category);

        if (!file) {
          return res.status(400).json({ error: "No file uploaded" });
        }
        if (!categoryResult.success) {
          return res.status(400).json({ error: "Invalid category" });
        }

        let textContent = "";
        const fileName = file.originalname.slice(0, 200);

        if (file.mimetype === "text/plain") {
          textContent = file.buffer.toString("utf-8");
        } else if (file.mimetype === "application/pdf") {
          const pdfData = await pdfParse(file.buffer);
          textContent = pdfData.text;
        }

        if (!textContent.trim()) {
          return res.status(400).json({ error: "Could not extract text from file" });
        }

        const maxChunkSize = 8000;
        const chunks: string[] = [];
        if (textContent.length <= maxChunkSize) {
          chunks.push(textContent.trim());
        } else {
          const paragraphs = textContent.split(/\n\n+/);
          let currentChunk = "";

          for (const paragraph of paragraphs) {
            if ((currentChunk + paragraph).length > maxChunkSize && currentChunk) {
              chunks.push(currentChunk.trim());
              currentChunk = paragraph;
            } else {
              currentChunk += (currentChunk ? "\n\n" : "") + paragraph;
            }
          }
          if (currentChunk.trim()) chunks.push(currentChunk.trim());
        }

        const createdItems = [];
        for (let index = 0; index < chunks.length; index += 1) {
          const title = chunks.length > 1 ? `${fileName} (第${index + 1}部分)` : fileName;
          const [item] = await db
            .insert(knowledgeBase)
            .values({
              title,
              content: chunks[index],
              category: categoryResult.data,
              keywords: [fileName.replace(/\.[^.]+$/, "")],
            })
            .returning();
          createdItems.push(item);
        }

        return res.status(201).json({
          message: `Successfully created ${createdItems.length} knowledge base entry(ies)`,
          items: createdItems,
        });
      } catch (error) {
        console.error("Error uploading knowledge base file:", error instanceof Error ? error.message : "Unknown error");
        return res.status(500).json({ error: "Failed to upload file" });
      }
    },
  );

  app.put("/api/admin/knowledge-base/:id", adminAuth, async (req: Request, res: Response) => {
    try {
      const id = Number.parseInt(String(req.params.id), 10);
      if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({ error: "Invalid ID" });
      }

      const parsed = knowledgeBaseSchema.partial().safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid update data" });
      }

      const updateData: Record<string, any> = {
        ...parsed.data,
        updatedAt: sql`CURRENT_TIMESTAMP`,
      };
      if (parsed.data.keywords !== undefined) {
        updateData.keywords = parsed.data.keywords
          ? parsed.data.keywords.split(",").map((keyword) => keyword.trim()).filter(Boolean)
          : [];
      }

      const [item] = await db
        .update(knowledgeBase)
        .set(updateData)
        .where(eq(knowledgeBase.id, id))
        .returning();

      if (!item) {
        return res.status(404).json({ error: "Item not found" });
      }
      return res.json(item);
    } catch (error) {
      console.error("Error updating knowledge base item:", error instanceof Error ? error.message : "Unknown error");
      return res.status(500).json({ error: "Failed to update knowledge base item" });
    }
  });

  app.delete("/api/admin/knowledge-base/:id", adminAuth, async (req: Request, res: Response) => {
    try {
      const id = Number.parseInt(String(req.params.id), 10);
      if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({ error: "Invalid ID" });
      }
      await db.delete(knowledgeBase).where(eq(knowledgeBase.id, id));
      return res.status(204).end();
    } catch (error) {
      console.error("Error deleting knowledge base item:", error instanceof Error ? error.message : "Unknown error");
      return res.status(500).json({ error: "Failed to delete knowledge base item" });
    }
  });

  app.get("/api/admin/conversations", adminAuth, async (_req: Request, res: Response) => {
    try {
      const allConversations = await db.select().from(conversations).orderBy(desc(conversations.createdAt));
      return res.json(allConversations);
    } catch (error) {
      console.error("Error fetching conversations:", error instanceof Error ? error.message : "Unknown error");
      return res.status(500).json({ error: "Failed to fetch conversations" });
    }
  });

  app.get("/api/admin/conversations/:id/messages", adminAuth, async (req: Request, res: Response) => {
    try {
      const id = Number.parseInt(String(req.params.id), 10);
      if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({ error: "Invalid ID" });
      }
      const chatMessages = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, id))
        .orderBy(messages.createdAt);
      return res.json(chatMessages);
    } catch (error) {
      console.error("Error fetching messages:", error instanceof Error ? error.message : "Unknown error");
      return res.status(500).json({ error: "Failed to fetch messages" });
    }
  });
}
