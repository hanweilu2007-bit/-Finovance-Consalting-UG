import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { registerChatbotRoutes } from "./chatbot";
import { createRateLimiter } from "./security";

const leadLimiter = createRateLimiter({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: "Too many contact requests. Please try again later.",
});

const requiredConsent = (message: string) =>
  z.preprocess(
    (value) => value === true || value === "true",
    z.literal(true, {
      errorMap: () => ({ message }),
    }),
  );

export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  registerChatbotRoutes(app);

  // Create Lead (Contact Form)
  app.post(api.leads.create.path, leadLimiter, async (req, res) => {
    try {
      // Keep the original consent requirement after normalizing HTML/JSON boolean values.
      const bodySchema = api.leads.create.input.extend({
        consentToPrivacy: requiredConsent("请阅读并同意隐私政策"),
        acceptedDisclaimer: requiredConsent("请阅读并确认免责声明"),
      });

      const input = bodySchema.parse(req.body);
      const lead = await storage.createLead(input);

      // Do not return personal data to the browser after it has been stored.
      res.status(201).json({ id: lead.id, createdAt: lead.createdAt });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0]?.message || "提交内容无效",
          field: err.errors[0]?.path.join("."),
        });
      }
      throw err;
    }
  });

  return httpServer;
}
